"""Durable E3 blind novelty checkpoint sealing.

E3-X/Y/Z external results are accepted proposals only.  Before any coverage,
gap, cumulative-corpus, or holdout reveal, every accepted blind result and its
pre-reveal discovery records are sealed in canonical history on one exact cut.

Manual external execution does not self-certify stronger independence than the
accepted attempt/knowledge/isolation records already provide.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
from typing import Any

from ..coordinator import Coordinator
from ..core.canonical_json import canonical_bytes
from ..core.errors import ValidationError
from ..core.registry import canonical_reference_set
from ..history.objects import CanonicalObject, CommandEnvelope
from ..history.store import TransactionalHistoryStore
from .assignments import _command_id, _current_cut, _external_ref
from .inbox import _same_ref, _with_ref_class
from .manual_stage import StageBatch, StageResultInbox


@dataclass(frozen=True)
class E3BlindCheckpointSummary:
    campaign_id: str
    checkpoint_input_history_cut: dict[str, Any]
    checkpoint_refs: dict[str, dict[str, Any]]
    discovery_refs: dict[
        str, tuple[dict[str, Any], ...]
    ]
    already_sealed: bool
    accepted_commit_seq: int


def _fingerprint_finding(
    value: dict[str, Any],
) -> str:
    return hashlib.sha256(
        canonical_bytes(value)
    ).hexdigest()


def _accepted_result_for_job(
    store: TransactionalHistoryStore,
    job,
    cut: dict[str, Any],
) -> dict[str, Any]:
    rows = [
        row
        for row in store.accepted_records(
            "bdb_audit_lane_result",
            cut,
        )
        if row["body"].get("stage_id") == "E3"
        and row["body"].get("phase_id") == "E3-BLIND"
        and _same_ref(
            row["body"].get("assignment_ref"),
            job.assignment_ref,
        )
    ]
    if len(rows) != 1:
        raise ValidationError(
            "E3_BLIND_RESULT_SET_INCOMPLETE",
            (
                f"{job.lane_slot}: expected 1 accepted "
                f"result, got {len(rows)}"
            ),
        )
    return rows[0]


class E3BlindCheckpointService:
    """Seal all E3 blind novelty lanes atomically before reveal."""

    def __init__(
        self,
        store: TransactionalHistoryStore,
        batch: StageBatch,
        inbox: StageResultInbox | None = None,
    ):
        if (
            batch.stage_id != "E3"
            or batch.phase_id != "E3-BLIND"
        ):
            raise ValidationError(
                "E3_BLIND_BATCH_REQUIRED",
                f"{batch.stage_id}/{batch.phase_id}",
            )
        self.store = store
        self.batch = batch
        self.inbox = inbox
        self.coordinator = Coordinator(store)

    def _existing(
        self,
        cut: dict[str, Any],
    ) -> dict[str, dict[str, Any]]:
        attempt_to_slot = {
            job.attempt_ref["revision_digest"]: slot
            for slot, job in self.batch.jobs.items()
        }
        found: dict[str, dict[str, Any]] = {}
        for row in self.store.accepted_records(
            "checkpoint",
            cut,
        ):
            body = row["body"]
            if (
                body.get("stage_id") != "E3"
                or body.get("phase_id") != "E3-BLIND"
            ):
                continue
            attempt = body.get("attempt_ref")
            if not isinstance(attempt, dict):
                continue
            slot = attempt_to_slot.get(
                attempt.get("revision_digest")
            )
            if slot is None:
                continue
            if (
                slot in found
                and found[slot]["ref"]["revision_digest"]
                != row["ref"]["revision_digest"]
            ):
                raise ValidationError(
                    "MULTIPLE_E3_BLIND_CHECKPOINTS",
                    slot,
                )
            found[slot] = row
        return found

    def seal(self) -> E3BlindCheckpointSummary:
        cut, prior_commit = _current_cut(
            self.store
        )
        if self.inbox is not None:
            self.inbox._load_accepted_state()
            missing = [
                slot
                for slot, state in (
                    self.inbox.lane_statuses.items()
                )
                if state.status != "ACCEPTED"
            ]
            blocked = [
                slot
                for slot, state in (
                    self.inbox.lane_statuses.items()
                )
                if state.status == "ACCEPTED"
                and state.completion_status
                != "LANE_COMPLETED"
            ]
            if missing or blocked:
                raise ValidationError(
                    "E3_BLIND_PHASE_NOT_COMPLETE",
                    (
                        f"missing={missing}; "
                        f"blocked={blocked}"
                    ),
                )

        existing = self._existing(cut)
        if existing:
            if set(existing) != set(
                self.batch.jobs
            ):
                raise ValidationError(
                    "PARTIAL_E3_BLIND_CHECKPOINT_SET"
                )
            seqs = {
                row["accepted_seq"]
                for row in existing.values()
            }
            if len(seqs) != 1:
                raise ValidationError(
                    "E3_BLIND_CHECKPOINT_CUT_DIVERGENCE"
                )
            from ..history.authority_hooks import (
                validate_e3_blind_checkpoint_provenance,
            )

            current = self.store.head()
            if current is None:
                raise ValidationError(
                    "E3_BLIND_CHECKPOINT_REQUIRES_ACCEPTED_RESULT"
                )
            conn = self.store._connect()
            try:
                for slot, row in existing.items():
                    job = self.batch.get_job(slot)
                    result = _accepted_result_for_job(
                        self.store,
                        job,
                        cut,
                    )
                    result_digest = result["ref"]["revision_digest"]
                    sealed = row["body"].get(
                        "sealed_output_refs",
                        (),
                    )
                    if (
                        _same_ref(
                            row["body"].get("attempt_ref"),
                            job.attempt_ref,
                        )
                        is False
                        or row["body"].get("lane_slot") != slot
                        or not any(
                            isinstance(ref, dict)
                            and ref.get("kind")
                            == "bdb_audit_lane_result"
                            and ref.get("revision_digest")
                            == result_digest
                            for ref in sealed
                        )
                    ):
                        raise ValidationError(
                            "E3_BLIND_CHECKPOINT_RESULT_BINDING_MISMATCH",
                            slot,
                        )
                    checkpoint = CanonicalObject(
                        "checkpoint",
                        row["body"],
                        row["ref"].get("schema_revision_ref"),
                        row["ref"].get("logical_id"),
                    )
                    validate_e3_blind_checkpoint_provenance(
                        checkpoint,
                        current=current,
                        con=conn,
                    )
            finally:
                conn.close()
            return E3BlindCheckpointSummary(
                campaign_id=self.batch.campaign_id,
                checkpoint_input_history_cut=dict(
                    next(iter(existing.values()))[
                        "body"
                    ][
                        "checkpoint_input_history_cut"
                    ]
                ),
                checkpoint_refs={
                    slot: _with_ref_class(
                        row["ref"],
                        "CONTENT_OR_PRIOR",
                    )
                    for slot, row in existing.items()
                },
                discovery_refs={
                    slot: tuple(
                        dict(ref)
                        for ref in row["body"].get(
                            "sealed_output_refs",
                            [],
                        )
                        if isinstance(ref, dict)
                        and ref.get("kind")
                        == "discovery_record"
                    )
                    for slot, row in existing.items()
                },
                already_sealed=True,
                accepted_commit_seq=next(
                    iter(seqs)
                ),
            )

        objects: list[CanonicalObject] = []
        checkpoints: dict[
            str, CanonicalObject
        ] = {}
        discoveries_by_slot: dict[
            str, list[CanonicalObject]
        ] = {}

        for slot in self.batch.lane_slots:
            job = self.batch.get_job(slot)
            result = _accepted_result_for_job(
                self.store,
                job,
                cut,
            )
            assignment = self.store.resolve_accepted(
                job.assignment_ref,
                cut,
            )
            attempt = self.store.resolve_accepted(
                assignment["body"]["attempt_ref"],
                cut,
            )
            lane_run = self.store.resolve_accepted(
                attempt["body"]["lane_run_ref"],
                cut,
            )
            stage_run = self.store.resolve_accepted(
                lane_run["body"]["stage_run_ref"],
                cut,
            )
            knowledge = self.store.resolve_accepted(
                assignment["body"][
                    "knowledge_state_ref"
                ],
                cut,
            )
            source = self.store.resolve_accepted(
                assignment["body"][
                    "source_generation_ref"
                ],
                cut,
            )

            discoveries: list[
                CanonicalObject
            ] = []
            findings = result["body"].get(
                "findings",
                [],
            )
            if not isinstance(findings, list):
                raise ValidationError(
                    "INVALID_FINDING_STRUCTURE",
                    slot,
                )
            for index, finding in enumerate(
                findings
            ):
                if not isinstance(
                    finding,
                    dict,
                ):
                    raise ValidationError(
                        "INVALID_FINDING_STRUCTURE",
                        slot,
                    )
                discovery = CanonicalObject(
                    "discovery_record",
                    {
                        "discovery_id": (
                            f"disc_E3_{slot}_"
                            f"{result['ref']['revision_digest'][:12]}_"
                            f"{index + 1}"
                        ),
                        "lane_run_ref": _with_ref_class(
                            lane_run["ref"],
                            "PRIOR_ACCEPTED_ONLY",
                        ),
                        "attempt_ref": _with_ref_class(
                            attempt["ref"],
                            "PRIOR_ACCEPTED_ONLY",
                        ),
                        "source_generation_ref": (
                            _with_ref_class(
                                source["ref"],
                                "PRIOR_ACCEPTED_ONLY",
                            )
                        ),
                        "discovery_input_history_cut": (
                            cut
                        ),
                        "knowledge_state_ref": (
                            _with_ref_class(
                                knowledge["ref"],
                                "PRIOR_ACCEPTED_ONLY",
                            )
                        ),
                        "method_ref": _external_ref(
                            "external_profile_ref",
                            f"e3_blind_external_{slot}",
                            "HISTORY_CONTEXT_BINDING",
                        ),
                        "producer_ref": prior_commit.get(
                            "actor_ref",
                            "installation-owner",
                        ),
                        "surface_location_refs": [],
                        "own_observation_refs": [],
                        "stage_id": "E3",
                        "phase_id": "E3-BLIND",
                        "lane_slot": slot,
                        "result_proposal_digest": (
                            result["ref"][
                                "revision_digest"
                            ]
                        ),
                        "submission_finding_index": (
                            index
                        ),
                        "submission_finding_fingerprint": (
                            _fingerprint_finding(
                                finding
                            )
                        ),
                        "origin_classification": (
                            "PRE_REVEAL_DISCOVERY"
                        ),
                        "discovery_mode": (
                            "BLIND_NOVELTY"
                        ),
                    },
                )
                discoveries.append(discovery)
                objects.append(discovery)
            discoveries_by_slot[slot] = discoveries

            sealed_refs = canonical_reference_set(
                [
                    _with_ref_class(
                        result["ref"],
                        "CONTENT_OR_PRIOR",
                    ),
                    *[
                        item.as_ref(
                            ref_class=(
                                "CONTENT_OR_PRIOR"
                            )
                        ).as_dict()
                        for item in discoveries
                    ],
                ]
            )
            checkpoint = CanonicalObject(
                "checkpoint",
                {
                    "checkpoint_id": (
                        "checkpoint_e3_blind_"
                        + hashlib.sha256(
                            (
                                slot
                                + ":"
                                + result["ref"][
                                    "revision_digest"
                                ]
                                + ":"
                                + str(
                                    cut[
                                        "accepted_head_seq"
                                    ]
                                )
                            ).encode("utf-8")
                        ).hexdigest()[:24]
                    ),
                    "stage_id": "E3",
                    "phase_id": "E3-BLIND",
                    "lane_slot": slot,
                    "stage_run_ref": _with_ref_class(
                        stage_run["ref"],
                        "PRIOR_ACCEPTED_ONLY",
                    ),
                    "lane_run_ref": _with_ref_class(
                        lane_run["ref"],
                        "PRIOR_ACCEPTED_ONLY",
                    ),
                    "attempt_ref": _with_ref_class(
                        attempt["ref"],
                        "PRIOR_ACCEPTED_ONLY",
                    ),
                    "source_generation_ref": (
                        _with_ref_class(
                            source["ref"],
                            "PRIOR_ACCEPTED_ONLY",
                        )
                    ),
                    "checkpoint_input_history_cut": (
                        cut
                    ),
                    "knowledge_state_ref": (
                        _with_ref_class(
                            knowledge["ref"],
                            "PRIOR_ACCEPTED_ONLY",
                        )
                    ),
                    "sealed_output_refs": (
                        sealed_refs
                    ),
                    "governing_policy_ref": (
                        prior_commit[
                            "governing_policy_ref"
                        ]
                    ),
                },
            )
            checkpoints[slot] = checkpoint
            objects.append(checkpoint)

        head = self.store.head()
        if head is None:
            raise ValidationError(
                "CAMPAIGN_NOT_INITIALIZED"
            )
        seed = ":".join(
            sorted(
                obj.digest
                for obj in checkpoints.values()
            )
        )
        command = CommandEnvelope(
            command_id=_command_id(
                "e3_blind_checkpoint:" + seed
            ),
            command_kind="RECORD_FOUNDATION_FACT",
            actor_ref=prior_commit.get(
                "actor_ref",
                "installation-owner",
            ),
            expected_parent_head={
                "tag": "ACCEPTED_HEAD_REF",
                **head.as_dict(),
            },
            governing_policy_ref=prior_commit[
                "governing_policy_ref"
            ],
            governing_spec_refs=tuple(
                prior_commit.get(
                    "governing_spec_refs",
                    (),
                )
            ),
            idempotency_scope=(
                "e3_blind_checkpoint:" + seed
            ),
            campaign_ref=head.campaign_id,
        )
        accepted = self.coordinator.accept(
            command,
            immutable_objects=objects,
            expected_head=head,
        )
        return E3BlindCheckpointSummary(
            campaign_id=self.batch.campaign_id,
            checkpoint_input_history_cut=dict(
                cut
            ),
            checkpoint_refs={
                slot: obj.as_ref(
                    ref_class="CONTENT_OR_PRIOR"
                ).as_dict()
                for slot, obj in checkpoints.items()
            },
            discovery_refs={
                slot: tuple(
                    obj.as_ref(
                        ref_class="CONTENT_OR_PRIOR"
                    ).as_dict()
                    for obj in rows
                )
                for slot, rows in (
                    discoveries_by_slot.items()
                )
            },
            already_sealed=False,
            accepted_commit_seq=(
                accepted.head.commit_seq
            ),
        )


__all__ = [
    "E3BlindCheckpointSummary",
    "E3BlindCheckpointService",
]
